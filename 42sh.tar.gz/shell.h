#ifndef SHELL_H
#define SHELL_H

void initialize(void);

struct tree_node;
void run_command(struct tree_node* n);

// ...

#endif
